# jekyll-true-minimal
Minimal and ascetic theme for jekyll.
Live demo: https://cyevgeniy.github.io/jekyll-true-minimal/
